package com.rohit.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.rohit.beans.*;
public class EmpDao {

	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cdac_demo","root","root");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	
	/*INSERT INTO demo VALUES (1,"Emp1");
	INSERT INTO demo VALUES (2,"Emp2");
	INSERT INTO demo VALUES (3,"Emp3");
	INSERT INTO demo VALUES (4,"Emp4");
	INSERT INTO demo VALUES (5,"Emp5");
	INSERT INTO demo VALUES (6,"Emp6");
	INSERT INTO demo VALUES (7,"Emp7");
	INSERT INTO demo VALUES (8,"Emp8");
	INSERT INTO demo VALUES (9,"Emp9");
	INSERT INTO demo VALUES (10,"Emp10");
	INSERT INTO demo VALUES (11,"Emp11");
	INSERT INTO demo VALUES (12,"Emp12");
	INSERT INTO demo VALUES (13,"Emp13");
	INSERT INTO demo VALUES (14,"Emp14");
	INSERT INTO demo VALUES (15,"Emp15");
	INSERT INTO demo VALUES (16,"Emp16");
	INSERT INTO demo VALUES (17,"Emp17");
	INSERT INTO demo VALUES (18,"Emp18");
	INSERT INTO demo VALUES (19,"Emp19");
	INSERT INTO demo VALUES (20,"Emp20");
	INSERT INTO demo VALUES (21,"Emp21");
	INSERT INTO demo VALUES (22,"Emp22");
	INSERT INTO demo VALUES (23,"Emp23");
	INSERT INTO demo VALUES (24,"Emp24");
	INSERT INTO demo VALUES (25,"Emp25");
	INSERT INTO demo VALUES (26,"Emp26");
	INSERT INTO demo VALUES (27,"Emp27");
	INSERT INTO demo VALUES (28,"Emp28");
	INSERT INTO demo VALUES (29,"Emp29");
	INSERT INTO demo VALUES (30,"Emp30");
	INSERT INTO demo VALUES (31,"Emp31");
	INSERT INTO demo VALUES (32,"Emp32");
	INSERT INTO demo VALUES (33,"Emp33");
	INSERT INTO demo VALUES (34,"Emp34");
	INSERT INTO demo VALUES (35,"Emp35");
	INSERT INTO demo VALUES (36,"Emp36");


	SELECT * FROM demo LIMIT 0,5;*/

	public static List<Emp> getRecords(int start,int total){
		List<Emp> list=new ArrayList<Emp>();
		try{
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement("select * from demo limit "+(start-1)+","+total);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Emp e=new Emp();
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				list.add(e);
			}
			con.close();
		}catch(Exception e){
			System.out.println(e);
		}
		return list;
	}
}
